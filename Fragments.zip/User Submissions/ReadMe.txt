User Submitted Fragments
------------------------

TBD
