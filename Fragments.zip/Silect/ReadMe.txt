Silect Software Fragments
-------------------------

Fragments in this folder were created by Silect Software.
