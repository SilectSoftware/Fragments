Silect Software Fragments
-------------------------

TBD
