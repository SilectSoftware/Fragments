Silect Software Fragments
-------------------------

TBD (something)
